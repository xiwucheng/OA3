// OAKitsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OAKits.h"
#include "OAKitsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
//MBN_CELLULAR_CLASS_CDMA

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// COAKitsDlg dialog




COAKitsDlg::COAKitsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COAKitsDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void COAKitsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(COAKitsDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_START, &COAKitsDlg::OnBnClickedStart)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CBR, &COAKitsDlg::OnBnClickedCbr)
	ON_BN_CLICKED(IDC_CLEAR, &COAKitsDlg::OnBnClickedClear)
END_MESSAGE_MAP()


// COAKitsDlg message handlers

BOOL COAKitsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	EnableMenuItem(::GetSystemMenu(m_hWnd,FALSE),SC_CLOSE,MF_BYCOMMAND|MF_DISABLED);
	char szIP[MAX_PATH]={0};
	int port;
	char szDir[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szDir);
	strcat(szDir,"\\OAKits.ini");
	GetPrivateProfileString("OAKitsCfg","IP","192.168.1.10",szIP,MAX_PATH,szDir);
	CIPAddressCtrl* pIP = (CIPAddressCtrl*)GetDlgItem(IDC_IP);
	struct in_addr addr;
	addr.S_un.S_addr = inet_addr(szIP);
	pIP->SetAddress(addr.S_un.S_un_b.s_b1,addr.S_un.S_un_b.s_b2,addr.S_un.S_un_b.s_b3,addr.S_un.S_un_b.s_b4);
	port = GetPrivateProfileInt("OAKitsCfg","Port",400,szDir);
	SetDlgItemInt(IDC_PORT,port,0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void COAKitsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void COAKitsDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR COAKitsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void COAKitsDlg::OnBnClickedStart()
{
	// TODO: Add your control notification handler code here
	char szDir[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szDir);
	strcat(szDir,"\\OAKits.ini");
	CIPAddressCtrl* pIP = (CIPAddressCtrl*)GetDlgItem(IDC_IP);
	DWORD addr;
	pIP->GetAddress(addr);
	m_ip.Format("%d.%d.%d.%d",(addr&0xff000000)>>24,(addr&0xff0000)>>16,(addr&0xff00)>>8,addr&0xff);
	m_port=GetDlgItemInt(IDC_PORT,0,0);
	WritePrivateProfileString("OAKitsCfg","IP",(LPCSTR)m_ip,szDir);
	CString ip;
	ip.Format("%d",m_port);
	WritePrivateProfileString("OAKitsCfg","Port",(LPCSTR)ip,szDir);
	m_hKeyThread = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)KeyThread,this,0,NULL);

}

void COAKitsDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: Add your message handler code here
}

void COAKitsDlg::AddLog(CString log)
{
	CString buff,tmp;
	GetDlgItem(IDC_LOG)->GetWindowText(buff);
	tmp=log;
	//tmp+="\r\n";
	buff+=tmp;
	CEdit * output=(CEdit *)GetDlgItem(IDC_LOG);
	output->SetWindowText(buff);
	output->LineScroll(output->GetLineCount());
}

void COAKitsDlg::OnBnClickedCbr()
{
	// TODO: Add your control notification handler code here
	char szDir[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szDir);
	strcat(szDir,"\\OAKits.ini");
	CIPAddressCtrl* pIP = (CIPAddressCtrl*)GetDlgItem(IDC_IP);
	DWORD addr;
	pIP->GetAddress(addr);
	m_ip.Format("%d.%d.%d.%d",(addr&0xff000000)>>24,(addr&0xff0000)>>16,(addr&0xff00)>>8,addr&0xff);
	m_port=GetDlgItemInt(IDC_PORT,0,0);
	WritePrivateProfileString("OAKitsCfg","IP",(LPCSTR)m_ip,szDir);
	CString ip;
	ip.Format("%d",m_port);
	WritePrivateProfileString("OAKitsCfg","Port",(LPCSTR)ip,szDir);
	m_hCBRThread = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)CBRThread,this,0,NULL);
}

UINT COAKitsDlg::KeyThread(LPVOID lp)
{
	COAKitsDlg* p = (COAKitsDlg*)lp;
	CProgressCtrl* pProgBar = (CProgressCtrl*)p->GetDlgItem(IDC_PROGRESS1);
	//pProgBar->SetBkColor(RGB(0,224,0));
	pProgBar->SetRange(0,100);
	pProgBar->SendMessage(PBM_SETBARCOLOR, 0, RGB(0,224,0));
	pProgBar->SetPos(0);

	BOOL retval;
	CString szCmd;
	PROCESS_INFORMATION pi={0};
	STARTUPINFO si={0};
	SECURITY_ATTRIBUTES sa={0};
	HANDLE hReadPipe,hWritePipe;
	sa.bInheritHandle=TRUE;
	sa.nLength=sizeof SECURITY_ATTRIBUTES;
	sa.lpSecurityDescriptor=NULL;
	retval=CreatePipe(&hReadPipe,&hWritePipe,&sa,0);
	si.cb=sizeof STARTUPINFO;
	si.wShowWindow=SW_HIDE;
	si.dwFlags=STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdOutput=si.hStdError=hWritePipe;
	DWORD dwLen,dwRead,dwActLen,retCode;
	p->GetDlgItem(IDC_START)->EnableWindow(0);
	p->GetDlgItem(IDC_CBR)->EnableWindow(0);
	p->GetDlgItem(IDOK)->EnableWindow(0);
	char buff[256] = {0};


	szCmd.Format("cmd.exe /c keyreport.exe test %s %d",(LPSTR)(LPCSTR)p->m_ip,p->m_port);
	retval=CreateProcess(NULL,(LPSTR)(LPCSTR)szCmd,&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	GetExitCodeProcess(pi.hProcess,&retCode);
	if (retCode)
	{
		p->MessageBox("connect server failed","Connectivity",MB_ICONERROR);
		goto __end;
	}


	p->AddLog("get key from server\r\n");
	retval=CreateProcess(NULL,"cmd.exe /c oa3tool.exe /assemble /configfile=oa3tool.cfg",&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	GetExitCodeProcess(pi.hProcess,&retCode);
	if (retCode)
	{
		p->MessageBox("Get key failed","Key",MB_ICONERROR);
		goto __end;
	}
	pProgBar->SetPos(25);

	p->AddLog("send key information to server\r\n");
	szCmd.Format("cmd.exe /c keyreport.exe %s %d",(LPSTR)(LPCSTR)p->m_ip,p->m_port);
	retval=CreateProcess(NULL,(LPSTR)(LPCSTR)szCmd,&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	pProgBar->SetPos(50);

	p->AddLog("erase key from bios\r\n");
	retval=CreateProcess(NULL,"cmd.exe /c afuwin.exe /oad",0,0,0,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	pProgBar->SetPos(75);
	p->AddLog("write key into bios\r\n");
	retval=CreateProcess(NULL,"cmd.exe /c afuwin.exe /aoa3.bin",0,0,0,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	GetExitCodeProcess(pi.hProcess,&retCode);
	pProgBar->SetPos(100);

	if (retCode)
	{
		p->MessageBox("Inject key to BIOS failed","Injection",MB_ICONERROR);
		goto __end;
	}


	p->AddLog("reboot tablet\r\n");
	retval=CreateProcess(NULL,"cmd.exe /c shutdown -r -t 0",&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	goto __ok;
__end:

	pProgBar->SendMessage(PBM_SETBARCOLOR, 0, RGB(255,0,0));
	//pProgBar->SetBkColor(RGB(255,0,0));
	pProgBar->SetPos(100);
__ok:
	CloseHandle(hWritePipe);
	CloseHandle(hReadPipe);
	p->GetDlgItem(IDC_START)->EnableWindow();
	p->GetDlgItem(IDC_CBR)->EnableWindow();
	p->GetDlgItem(IDOK)->EnableWindow();

	return 0;
}

UINT COAKitsDlg::CBRThread(LPVOID lp)
{
	COAKitsDlg* p = (COAKitsDlg*)lp;
	CProgressCtrl* pProgBar = (CProgressCtrl*)p->GetDlgItem(IDC_PROGRESS1);
	//pProgBar->SetBkColor(RGB(0,224,0));
	pProgBar->SetRange(0,100);
	pProgBar->SendMessage(PBM_SETBARCOLOR, 0, RGB(0,224,0));
	pProgBar->SetPos(0);

	BOOL retval;
	CString szCmd;
	char buff[256] = {0};
	PROCESS_INFORMATION pi={0};
	STARTUPINFO si={0};
	SECURITY_ATTRIBUTES sa={0};
	HANDLE hReadPipe,hWritePipe;
	DWORD dwLen,dwRead,dwActLen,retCode;
	sa.bInheritHandle=TRUE;
	sa.nLength=sizeof SECURITY_ATTRIBUTES;
	sa.lpSecurityDescriptor=NULL;
	retval=CreatePipe(&hReadPipe,&hWritePipe,&sa,0);
	si.cb=sizeof STARTUPINFO;
	si.wShowWindow=SW_HIDE;
	si.dwFlags=STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.hStdOutput=si.hStdError=hWritePipe;


	szCmd.Format("cmd.exe /c keyreport.exe test %s %d",(LPSTR)(LPCSTR)p->m_ip,p->m_port);
	retval=CreateProcess(NULL,(LPSTR)(LPCSTR)szCmd,&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	GetExitCodeProcess(pi.hProcess,&retCode);
	if (retCode)
	{
		p->MessageBox("connect server failed","Connectivity",MB_ICONERROR);
		goto __end;
	}

	p->AddLog("upload CBR to server\r\n");
	retval=CreateProcess(NULL,"cmd.exe /c oa3tool.exe /report /configfile=oa3tool.cfg",&sa,&sa,TRUE,0,NULL,NULL,&si,&pi);
	p->GetDlgItem(IDC_START)->EnableWindow(0);
	p->GetDlgItem(IDC_CBR)->EnableWindow(0);
	p->GetDlgItem(IDOK)->EnableWindow(0);
	WaitForSingleObject(pi.hThread,INFINITE);
	dwLen=GetFileSize(hReadPipe,NULL);
	while (dwLen > 0)
	{
		dwActLen = min(dwLen,255);
		memset(buff,0,sizeof(buff));
		ReadFile(hReadPipe,buff,dwActLen,&dwRead,NULL);
		p->AddLog(buff);
		dwLen -= dwRead;
	}
	GetExitCodeProcess(pi.hProcess,&retCode);
	if (retCode)
	{
		p->MessageBox("CBR upload failed","CBR",MB_ICONERROR);
		goto __end;
	}
	pProgBar->SetPos(100);
	p->MessageBox("CBR upload successfully","CBR",MB_ICONINFORMATION);
	goto __ok;
__end:

	pProgBar->SendMessage(PBM_SETBARCOLOR, 0, RGB(255,0,0));
	pProgBar->SetPos(100);
__ok:
	CloseHandle(hWritePipe);
	CloseHandle(hReadPipe);
	p->GetDlgItem(IDC_START)->EnableWindow();
	p->GetDlgItem(IDC_CBR)->EnableWindow();
	p->GetDlgItem(IDOK)->EnableWindow();

	return 0;
}

void COAKitsDlg::OnBnClickedClear()
{
	// TODO: Add your control notification handler code here
	SetDlgItemText(IDC_LOG,NULL);
}
