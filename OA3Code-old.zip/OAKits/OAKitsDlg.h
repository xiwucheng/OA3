// OAKitsDlg.h : header file
//

#pragma once

// COAKitsDlg dialog
class COAKitsDlg : public CDialog
{
// Construction
public:
	COAKitsDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_OAKITS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;
	HANDLE m_hKeyThread,m_hCBRThread;
	CString m_ip;
	int m_port;
	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedStart();
public:
	afx_msg void OnDestroy();
public:
	void AddLog(CString log);
public:
	afx_msg void OnBnClickedCbr();
public:
	static UINT KeyThread(LPVOID lp);
public:
	static UINT CBRThread(LPVOID lp);
	afx_msg void OnBnClickedClear();
};
